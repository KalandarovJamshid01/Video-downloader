# Video Downloader Telegram Bot

📥 Telegram bot to download videos from YouTube, TikTok, and Instagram using `yt-dlp`.

## 🛠 How to Use

1. Install dependencies:
```bash
npm install
```

2. Install yt-dlp:
```bash
sudo curl -L https://yt-dlp.org/downloads/latest/yt-dlp -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp
```

3. Create a `.env` file and add your Telegram bot token:
```
BOT_TOKEN=your_token_here
```

4. Start the bot:
```bash
node index.js
```